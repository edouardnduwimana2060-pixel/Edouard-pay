# EdouardoCryptoDeals P2P — source project

This is a runnable Node.js starter app for the owner and customers. It includes customer signup/login, an admin dashboard, order records, editable default margin, user KYC status tracking, an audit log, and a server-side experimental Binance P2P quote adapter.

## Important: not production-ready
- The Binance P2P quote route shown here is an experimental public endpoint described in Binance's P2P Skills Hub, not a guaranteed stable public API contract. It may be blocked, changed, or unavailable for a fiat market. The app returns an error instead of inventing a rate when it fails. Verify current official documentation and usage terms before relying on it.
- ID + selfie matching is **not implemented**. The app deliberately does not collect/store identity images. For real identity verification, use a reputable KYC provider with liveness/selfie matching, explicit consent, a privacy notice, retention/deletion rules, access controls, and local-law review. Do not upload identity/selfie files into a basic web folder.
- This does not execute Binance orders, release crypto, or verify payments.
- Security controls included are a baseline, not a guarantee or security audit. Before production, add MFA for admin, email verification, password reset, secure backups, monitoring, tests, dependency updates, HTTPS, rate-limit review, and an independent security review.
- `audit_logs` records events, but not every possible system event; protect logs and set a retention policy.

## Run on a computer
1. Install Node.js 20+.
2. Extract the zip.
3. Copy `.env.example` to `.env`.
4. Set a random `SESSION_SECRET` of 32+ characters, `ADMIN_EMAIL`, and a unique admin password of at least 12 characters.
5. Run `npm install`, then `npm start`.
6. Open `http://localhost:3000`.
7. Admin can update KYC status labels, margin default, order statuses and view logs. Customers can register and manage their own orders.

## Deployment
Deploy to a server/platform that supports persistent storage for SQLite, use HTTPS, set `NODE_ENV=production`, and configure a trusted proxy only if one is actually present. For larger use, migrate SQLite and the session store to managed databases. Never put secrets in browser JavaScript or public repositories.

## Binance adapter
The app calls its server-side route `/api/p2p-rate?fiat=BIF&asset=USDT&tradeType=BUY`. No API key is requested for this public quote attempt. Do not add Binance account keys unless a documented authenticated feature truly requires them; never grant withdrawal permission to a key for a rate display app.
